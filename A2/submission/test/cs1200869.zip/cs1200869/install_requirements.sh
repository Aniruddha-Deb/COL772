# pip requirements
pip install -r requirements.txt
