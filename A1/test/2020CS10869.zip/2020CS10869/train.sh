python3 main.py train $1 $2 
