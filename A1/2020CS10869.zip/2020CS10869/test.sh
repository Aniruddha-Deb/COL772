python3 main.py test $1 $2 $3
